Durand Jean-Frédéric
Boukrou Malik

TP fonctionnel.

Exercice 5 :

Les objets ne suivent pas le curseur lors ce que l'on est derrière eux. Ils se déplace en sens inverse pour les coordonnées horizontales. En face cela fonctionne.

Exercice 6 :

Non testé.
