Durand Jean-Frédéric
Boukrou Malik

Doit contenir :
- ce que vous n'avez pas fait (et pourquoi). Précisez explicitement "tout à été fait et fonctionne parfaitement" si c'est le cas.
- difficultés rencontrées.
- commentaires éventuels sur le TP (points à éclaircir, longueur du sujet, etc). 


Question 13 :

Désormais, lorsque nous bloquons l'avion à la verticale (soit un angle de 90° par rapport au sol), le roll et le yaw ne sont plus identique.
Ceci permettant ainsi d'effectuer toutes les rotations.


Question 16 :
La caméra suit bien la voiture en ligne droite. Cependant lorsque l'on tourne celle-ci ne suit pas le même angle que la voiture.


Compte Rendu : TP fini & fonctionnel. Le seul petit bémol est exprimé ci-dessus pour la question 16.
