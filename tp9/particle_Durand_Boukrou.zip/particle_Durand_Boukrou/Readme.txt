Durand JF
Boukrou Malik

TP fonctionnel.

Question 12 : 

L'instabilité des spheres est due au fait qu'elles rentrent toutes en collision quasi permanente. Or dès qu'une sphère rentre en collision on l'a replace. Je pense que dans l'idéal il aurait fallu définir un coefficient a partir du quel la sphère n'est pas négligeable. Ainsi on n'aurait replacé la boule que si ce n'est pas négligeable au lieu de la faire bouger de qques pixels.

